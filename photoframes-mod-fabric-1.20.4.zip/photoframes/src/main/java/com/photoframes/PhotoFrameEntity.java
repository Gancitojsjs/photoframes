package com.photoframes;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Cuadro de 2x2 bloques que muestra una imagen. */
public class PhotoFrameEntity extends AbstractDecorationEntity {
    private static final TrackedData<String> IMAGE =
            DataTracker.registerData(PhotoFrameEntity.class, TrackedDataHandlerRegistry.STRING);

    public PhotoFrameEntity(EntityType<? extends PhotoFrameEntity> type, World world) {
        super(type, world);
    }

    public PhotoFrameEntity(World world, BlockPos pos, Direction direction) {
        super(PhotoFramesMod.PHOTO_FRAME_ENTITY, world, pos);
        this.setFacing(direction);
    }

    public String getImage() { return this.dataTracker.get(IMAGE); }
    public void setImage(String s) { this.dataTracker.set(IMAGE, s); }

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(IMAGE, "");
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putByte("facing", (byte) this.facing.getHorizontal());
        nbt.putString("Image", getImage());
        super.writeCustomDataToNbt(nbt);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        this.facing = Direction.fromHorizontal(nbt.getByte("facing"));
        setImage(nbt.getString("Image"));
        super.readCustomDataFromNbt(nbt);
        this.setFacing(this.facing);
    }

    @Override public int getWidthPixels() { return 32; }
    @Override public int getHeightPixels() { return 32; }

    @Override
    public void onBreak(@Nullable Entity breaker) {
        if (!this.getWorld().getGameRules().getBoolean(GameRules.DO_ENTITY_DROPS)) return;
        this.playSound(SoundEvents.ENTITY_PAINTING_BREAK, 1.0f, 1.0f);
        if (breaker instanceof PlayerEntity p && p.getAbilities().creativeMode) return;
        ItemStack drop = new ItemStack(PhotoFramesMod.PHOTO_FRAME_ITEM);
        drop.setCustomName(Text.literal(getImage()));
        this.dropStack(drop);
    }

    @Override
    public void onPlace() {
        this.playSound(SoundEvents.ENTITY_PAINTING_PLACE, 1.0f, 1.0f);
    }

    @Override
    public ItemStack getPickBlockStack() {
        ItemStack s = new ItemStack(PhotoFramesMod.PHOTO_FRAME_ITEM);
        s.setCustomName(Text.literal(getImage()));
        return s;
    }

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() {
        return new EntitySpawnS2CPacket(this, this.facing.getId(), this.getDecorationBlockPos());
    }

    @Override
    public void onSpawnPacket(EntitySpawnS2CPacket packet) {
        super.onSpawnPacket(packet);
        this.setFacing(Direction.byId(packet.getEntityData()));
    }
}
