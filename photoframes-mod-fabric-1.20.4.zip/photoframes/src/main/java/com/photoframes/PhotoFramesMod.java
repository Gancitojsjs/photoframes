package com.photoframes;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class PhotoFramesMod implements ModInitializer {
    public static final String MOD_ID = "photoframes";

    public static final EntityType<PhotoFrameEntity> PHOTO_FRAME_ENTITY = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(MOD_ID, "photo_frame"),
            FabricEntityTypeBuilder.<PhotoFrameEntity>create(SpawnGroup.MISC, PhotoFrameEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .trackRangeBlocks(10)
                    .trackedUpdateRate(Integer.MAX_VALUE)
                    .forceTrackedVelocityUpdates(false)
                    .build());

    public static final Item PHOTO_FRAME_ITEM = Registry.register(
            Registries.ITEM, new Identifier(MOD_ID, "photo_frame"),
            new PhotoFrameItem(new FabricItemSettings().maxCount(16)));

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(PHOTO_FRAME_ITEM));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(e -> e.add(PHOTO_FRAME_ITEM));
    }
}
