package com.photoframes.client;

import com.photoframes.PhotoFramesMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class PhotoFramesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        PhotoTextures.ensureFolder();
        EntityRendererRegistry.register(PhotoFramesMod.PHOTO_FRAME_ENTITY, PhotoFrameRenderer::new);
    }
}
