package com.photoframes.client;

import com.photoframes.PhotoFrameEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class PhotoFrameRenderer extends EntityRenderer<PhotoFrameEntity> {
    private static final Identifier WOOD = new Identifier("minecraft", "textures/block/dark_oak_planks.png");
    private static final Identifier PLACEHOLDER = new Identifier("minecraft", "textures/block/gray_concrete.png");

    public PhotoFrameRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(PhotoFrameEntity entity) {
        return PLACEHOLDER;
    }

    @Override
    public void render(PhotoFrameEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vcp, int light) {
        PhotoTextures.Photo photo = PhotoTextures.get(entity.getImage());

        // Mitad del tamaño del lienzo (el cuadro mide 2x2 bloques), respetando la proporción de la foto
        float hw = 1.0f, hh = 1.0f;
        if (photo != null) {
            if (photo.aspect() >= 1f) hh = 1.0f / photo.aspect();
            else hw = photo.aspect();
        }

        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - entity.getYaw()));

        // marco de madera (detrás) y la imagen (delante)
        quad(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(WOOD)), hw + 0.06f, hh + 0.06f, -0.010f, light);
        Identifier tex = photo != null ? photo.id() : PLACEHOLDER;
        quad(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(tex)), hw, hh, -0.020f, light);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vcp, light);
    }

    private static void quad(MatrixStack matrices, VertexConsumer vc, float hw, float hh, float z, int light) {
        MatrixStack.Entry e = matrices.peek();
        Matrix4f pm = e.getPositionMatrix();
        Matrix3f nm = e.getNormalMatrix();
        v(vc, pm, nm, hw, hh, z, 0, 0, light);
        v(vc, pm, nm, hw, -hh, z, 0, 1, light);
        v(vc, pm, nm, -hw, -hh, z, 1, 1, light);
        v(vc, pm, nm, -hw, hh, z, 1, 0, light);
    }

    private static void v(VertexConsumer vc, Matrix4f pm, Matrix3f nm, float x, float y, float z,
                          float u, float v, int light) {
        vc.vertex(pm, x, y, z).color(255, 255, 255, 255).texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nm, 0, 0, -1).next();
    }
}
