package com.photoframes.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Carga imágenes (archivo en .minecraft/photoframes o URL) sin bloquear el juego. */
public final class PhotoTextures {
    public record Photo(Identifier id, float aspect) {}

    private static final int MAX_SIDE = 1024;
    private static final Map<String, Photo> READY = new ConcurrentHashMap<>();
    private static final Set<String> LOADING = ConcurrentHashMap.newKeySet();
    private static final Set<String> FAILED = ConcurrentHashMap.newKeySet();

    private PhotoTextures() {}

    public static Path folder() {
        return FabricLoader.getInstance().getGameDir().resolve("photoframes");
    }

    public static void ensureFolder() {
        try { Files.createDirectories(folder()); } catch (Exception ignored) {}
    }

    /** Devuelve la foto si ya está lista; si no, empieza a cargarla y devuelve null. */
    public static Photo get(String name) {
        if (name == null || name.isBlank()) return null;
        Photo p = READY.get(name);
        if (p != null) return p;
        if (!FAILED.contains(name) && LOADING.add(name)) {
            Thread t = new Thread(() -> load(name), "PhotoFrames-Loader");
            t.setDaemon(true);
            t.start();
        }
        return null;
    }

    private static void load(String name) {
        try {
            byte[] raw = read(name);
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(raw));
            if (img == null) throw new IllegalStateException("Formato de imagen no soportado");
            img = downscale(img);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ImageIO.write(img, "png", out);
            NativeImage ni = NativeImage.read(new ByteArrayInputStream(out.toByteArray()));
            float aspect = (float) img.getWidth() / img.getHeight();
            Identifier id = new Identifier("photoframes",
                    "img/" + UUID.nameUUIDFromBytes(name.getBytes()).toString());
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(ni));
                READY.put(name, new Photo(id, aspect));
                LOADING.remove(name);
            });
        } catch (Throwable e) {
            System.err.println("[PhotoFrames] No se pudo cargar '" + name + "': " + e);
            FAILED.add(name);
            LOADING.remove(name);
        }
    }

    private static byte[] read(String name) throws Exception {
        if (name.startsWith("http://") || name.startsWith("https://")) {
            URLConnection c = new URL(name).openConnection();
            c.setRequestProperty("User-Agent", "Mozilla/5.0 PhotoFrames");
            c.setConnectTimeout(8000);
            c.setReadTimeout(15000);
            try (InputStream in = c.getInputStream()) { return in.readNBytes(20 * 1024 * 1024); }
        }
        Path base = folder().toAbsolutePath().normalize();
        Path file = base.resolve(name).normalize();
        if (!file.startsWith(base)) throw new SecurityException("Ruta no permitida");
        return Files.readAllBytes(file);
    }

    private static BufferedImage downscale(BufferedImage src) {
        int w = src.getWidth(), h = src.getHeight();
        float s = Math.min(1f, (float) MAX_SIDE / Math.max(w, h));
        int nw = Math.max(1, Math.round(w * s)), nh = Math.max(1, Math.round(h * s));
        BufferedImage dst = new BufferedImage(nw, nh, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = dst.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(src, 0, 0, nw, nh, null);
        g.dispose();
        return dst;
    }
}
