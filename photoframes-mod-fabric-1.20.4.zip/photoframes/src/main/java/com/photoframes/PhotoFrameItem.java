package com.photoframes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

/** El nombre del item (renombrado en un yunque) es el archivo o URL de la imagen. */
public class PhotoFrameItem extends Item {
    public PhotoFrameItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        BlockPos offset = ctx.getBlockPos().offset(ctx.getSide());
        Direction side = ctx.getSide();
        PlayerEntity player = ctx.getPlayer();
        ItemStack stack = ctx.getStack();
        World world = ctx.getWorld();

        if (side.getAxis().isVertical()) return ActionResult.FAIL;
        if (player != null && !player.canPlaceOn(offset, side, stack)) return ActionResult.FAIL;

        if (!stack.hasCustomName()) {
            if (player != null) player.sendMessage(Text.translatable("message.photoframes.needs_name"), true);
            return ActionResult.FAIL;
        }

        PhotoFrameEntity frame = new PhotoFrameEntity(world, offset, side);
        frame.setImage(stack.getName().getString().trim());

        if (!frame.canStayAttached()) {
            if (player != null) player.sendMessage(Text.translatable("message.photoframes.no_space"), true);
            return ActionResult.CONSUME;
        }
        if (!world.isClient) {
            frame.onPlace();
            world.emitGameEvent(player, GameEvent.ENTITY_PLACE, frame.getPos());
            world.spawnEntity(frame);
        }
        if (player == null || !player.getAbilities().creativeMode) stack.decrement(1);
        return ActionResult.success(world.isClient);
    }
}
