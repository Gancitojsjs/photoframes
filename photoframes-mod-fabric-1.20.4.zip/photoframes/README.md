# Photo Frames (Fabric 1.20.4)

Cuelga tus fotos en las paredes como cuadros (2x2 bloques).

## Uso
1. Pon tus imágenes (png/jpg/gif/bmp) en `.minecraft/photoframes/` (se crea al abrir el juego).
2. Craftea un Marco de fotos: 8 palos alrededor de 1 papel.
3. Renómbralo en un yunque con el nombre del archivo (`foto.png`) o una URL (`https://.../img.jpg`).
4. Click derecho en una pared. Al romperlo devuelve el marco con la misma imagen.

Nota: cada jugador ve la imagen desde su propia carpeta/URL; en servidores usa URLs.

## Compilar
Requiere JDK 17 y Gradle 8.5+:
    gradle wrapper --gradle-version 8.5
    ./gradlew build
El .jar queda en build/libs/. Instala Fabric Loader + Fabric API 1.20.4.
